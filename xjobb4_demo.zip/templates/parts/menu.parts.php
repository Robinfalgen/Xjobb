<header>
	<div class="logo">
		<a href="index.php"><img src="<?php echo IMG_DIR . 'logo.jpg' ?>" width="160" height="auto"></a>
	</div>
	
	<!--<input type="checkbox" id="menu" name="menu-box">
	<label for="menu">Produkter</label>-->
	<div class="menu">

		<div class="menu-category">
			<a href="index.php?action=products&category=1">Gitarrer</a>
		</div>
		<div class="menu-category">
			<a href="index.php?action=products&category=3">Baser</a>
		</div>
		<div class="menu-category">
			<a href="index.php?action=products&category=5">Tillbehör</a>
		</div>
	</div>
	<div class="cart-div"><?php
			require(TEMPLATES_FOLDER.'cart.tpl.php');
		?></div>
	
	
	<div class="search-bar">
		<?php //include(INCLUDES_FOLDER.'search.inc.php'); ?>
	</div>
	
	<div class="login"><!--
	</div>
	
	<?php //if(isset($_SESSION['cart'])) { echo "<div class='shopping-count'>".count($_SESSION['cart'])."</div>"; } else { echo "<div class='shopping-count hide'>".count($_SESSION['cart'])."</div>"; } ?>
	
	--></header>