<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="css/luftgitarr.menu.css" rel="stylesheet" type="text/css">
		
		<!--<link href="css/millhouse.account.css" rel="stylesheet" type="text/css">
		<link type="text/css" rel="stylesheet" href="css/millhouse.reg.css">
		<link href="css/millhouse.modals.css" rel="stylesheet" type="text/css">
		<link href="css/millhouse.css" rel="stylesheet" type="text/css">-->
		<script src="https://use.fontawesome.com/2db799d532.js"></script>
	</head>
	
	<body>
	
	<?php
		
		require(TEMPARTS.'menu.parts.php');
	?>
	
	<section id="content">