<?php

define("TEMPLATES_FOLDER", "templates/");
define("TEMPARTS", "templates/parts/");
define("INCLUDES_FOLDER", "inc/");
define("CONTROLLERS_FOLDER", "controllers/");
define("UPLOAD_DIR", "uploads/");
define("IMG_DIR", "imgs/");

?>