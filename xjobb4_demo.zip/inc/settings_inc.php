<?php
class DBSettings {
	protected $db_name = 'xjobb';
	protected $db_user = 'root';
	protected $db_pass = 'root';
	protected $db_host = 'localhost';
	
	}
	